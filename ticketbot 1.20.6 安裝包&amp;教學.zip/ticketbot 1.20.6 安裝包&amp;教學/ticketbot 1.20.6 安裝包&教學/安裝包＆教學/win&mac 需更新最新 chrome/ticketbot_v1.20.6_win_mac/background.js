function _0x5191(_0x5a97da, _0x4ff551) {
    const _0x43568a = _0x4356();
    _0x5191 = function (_0x5191e8, _0x2f6e88) {
      _0x5191e8 = _0x5191e8 - 173;
      let _0x27804c = _0x43568a[_0x5191e8];
      return _0x27804c;
    };
    return _0x5191(_0x5a97da, _0x4ff551);
  }
  const _0x134a13 = _0x5191;
  (function (_0x4b6f93, _0x574a0d) {
    const _0x29a4bb = _0x5191;
    const _0x3b1ed7 = _0x4b6f93();
    while (true) {
      try {
        const _0x28e613 = parseInt(_0x29a4bb(262)) / 1 + parseInt(_0x29a4bb(198)) / 2 * (parseInt(_0x29a4bb(204)) / 3) + -parseInt(_0x29a4bb(219)) / 4 + parseInt(_0x29a4bb(181)) / 5 + -parseInt(_0x29a4bb(223)) / 6 * (-parseInt(_0x29a4bb(242)) / 7) + parseInt(_0x29a4bb(273)) / 8 + -parseInt(_0x29a4bb(178)) / 9 * (parseInt(_0x29a4bb(187)) / 10);
        if (_0x28e613 === _0x574a0d) {
          break;
        } else {
          _0x3b1ed7.push(_0x3b1ed7.shift());
        }
      } catch (_0x1cf037) {
        _0x3b1ed7.push(_0x3b1ed7.shift());
      }
    }
  })(_0x4356, 374838);
  let versionTest = false;
  let doNotChangeWindowIds = [];
  let startedWindowIds = [];
  let stopForceReloadIds = [];
  let backendDomain = "http://43.139.122.175:8001";
  let settingsPage = "https://www.ticketbot-machine.com/";
  let getCurrentTab = async function () {
    const _0x48c3b7 = _0x134a13;
    let _0x3b0308 = {
      active: true,
      currentWindow: true
    };
    let [_0x19e971] = await chrome[_0x48c3b7(250)][_0x48c3b7(205)](_0x3b0308);
    return _0x19e971;
  };
  let openNewTab = function (_0x390eba) {
    const _0xdb053c = _0x134a13;
    console.log(_0xdb053c(271), _0x390eba);
    chrome.tabs[_0xdb053c(247)]({
      active: true,
      url: _0x390eba
    });
  };
  let sendMsg = async function (_0x1a8300) {
    const _0x1ab397 = _0x134a13;
    let _0x5768e9 = await getCurrentTab();
    chrome[_0x1ab397(250)][_0x1ab397(202)](_0x5768e9.id, {
      action: _0x1a8300
    }, function (_0x3b3588) {});
    return true;
  };
  let getCurrentTime = async function () {
    const _0x51b6c4 = _0x134a13;
    let _0x46cfb5 = _0x51b6c4(191);
    try {
      const _0x15d845 = await fetch(_0x46cfb5);
      const _0x31c5c4 = await _0x15d845[_0x51b6c4(185)]();
      return _0x31c5c4.unixtime;
    } catch (_0x56670f) {
      return Math[_0x51b6c4(231)](Date[_0x51b6c4(260)]() / 1000);
    }
  };
  let checkDeadline = async function (_0x31871c) {
    const _0x49eee7 = _0x134a13;
    let _0x46c667 = await chrome[_0x49eee7(188)][_0x49eee7(206)][_0x49eee7(241)]([_0x49eee7(197), _0x49eee7(220), "hkticketkiller_enabled", _0x49eee7(174)]);
    if (!_0x46c667) {
      return;
    }
    let _0x9248e1 = _0x46c667.hkticketkiller_deadline;
    if (versionTest) {
      _0x9248e1 = 1767157200;
    }
    let _0x375aca = {
      action: _0x49eee7(245),
      deadline: _0x9248e1,
      key: _0x46c667[_0x49eee7(197)]
    };
    if (_0x46c667.hkticketkiller_enabled) {
      _0x375aca.disable = false;
    } else if (_0x46c667[_0x49eee7(174)]) {
      _0x375aca.disable = true;
    } else if (_0x9248e1) {
      console[_0x49eee7(216)](_0x49eee7(221));
      let _0x4d2abd = await getCurrentTime();
      if (!_0x9248e1 || !_0x4d2abd) {
        _0x375aca[_0x49eee7(276)] = true;
      } else if (_0x4d2abd > _0x9248e1) {
        _0x375aca[_0x49eee7(276)] = true;
      } else {
        _0x375aca[_0x49eee7(276)] = false;
      }
      if (_0x375aca[_0x49eee7(276)]) {
        console[_0x49eee7(216)](_0x49eee7(255));
        await chrome[_0x49eee7(188)].local.set({
          hkticketkiller_disabled: true
        });
      } else {
        console[_0x49eee7(216)](_0x49eee7(211));
        await chrome[_0x49eee7(188)][_0x49eee7(206)][_0x49eee7(213)]({
          hkticketkiller_enabled: true
        });
      }
    } else {
      console.log("checkDeadline: no key");
      _0x375aca[_0x49eee7(276)] = true;
    }
    if (!_0x31871c) {
      return;
    }
    if (_0x31871c[_0x49eee7(189)] && _0x31871c.tab.id) {
      chrome[_0x49eee7(250)][_0x49eee7(202)](_0x31871c[_0x49eee7(189)].id, _0x375aca);
    } else {
      chrome.runtime[_0x49eee7(202)](_0x375aca);
    }
  };
  const hourlyLoop = {
    getNextHourTimestamp: function () {
      const _0x570e26 = _0x134a13;
      const _0x3b2f65 = new Date();
      const _0x349898 = new Date(_0x3b2f65);
      _0x349898[_0x570e26(226)](_0x3b2f65[_0x570e26(258)]() + 1, 0, 0, 0);
      return _0x349898[_0x570e26(217)]();
    },
    setNextAlarm: function () {
      const _0xe92c27 = _0x134a13;
      const _0x51ff99 = this[_0xe92c27(177)]();
      chrome[_0xe92c27(268)][_0xe92c27(247)]("hourlyLoop", {
        when: _0x51ff99
      });
      console[_0xe92c27(216)](_0xe92c27(173) + new Date(_0x51ff99)[_0xe92c27(240)]());
    }
  };
  function _0x4356() {
    const _0x50d2c4 = ["https://hkticketkiller-backend-latest.vercel.app", "updateOptions", "validation data:", "getOptions", "Refreshing tab ", "onMessageExternal", "hourlyLoop: Next refresh scheduled for ", "hkticketkiller_disabled", "unixtime", "Value currently is ", "getNextHourTimestamp", "2745pDCMid", "getInfo", "checkDeadline", "3667050BgCzeT", "forEach", "key", "setNextAlarm", "json", "catch", "57190FYRHrB", "storage", "tab", "onMessage", "https://worldtimeapi.org/api/timezone/Asia/Hong_Kong", "runtime", "setDeadline", "addListener", "hkticketkiller_success_windowId", "成功進入購票頁面", "hkticketkiller_key", "734ISaNZt", "length", "deadline", "hkticketkiller_success_tabId", "sendMessage", "normal", "2001HckFgM", "query", "local", "hkticketkiller_success", "maximizedWindow", "hourlyLoop", "delay", "checkDeadline: enabled", "stopForceReload", "set", "display", "getOptionsCallback", "log", "getTime", "splice", "522080vnpEVI", "hkticketkiller_deadline", "checkDeadline: check again", "action", "12AIoJxQ", "stopForceReloadIds", "cityline", "setHours", "Error:", "indexOf", "width", "onCreated", "floor", "error", "setZoom", "url", "cors", "/v0/validation/", "/tc/", "windowId", "round", "toLocaleString", "get", "1507303saQyzw", "windows", "getURL", "checkDeadlineCallback", "notifications", "create", "saveWindowId", "message", "tabs", "*://*.cityline.com/*", "workArea", "msg received from bubble app", "options", "checkDeadline: disabled", "then", "push", "getHours", "forceReload", "now", "from", "324303EwFKBj", "includes", "hkticketkiller_options", "getDeadline", "onButtonClicked", "update", "alarms", "name", "getDeadlineCallback", "openNewTab", "session", "4131944YtewBe", "setWindowSize", "basic", "disable", "reload", "page"];
    _0x4356 = function () {
      return _0x50d2c4;
    };
    return _0x4356();
  }
  chrome[_0x134a13(268)].clear(_0x134a13(209), function () {
    hourlyLoop.setNextAlarm();
  });
  chrome[_0x134a13(268)].onAlarm[_0x134a13(194)](function (_0x2dfca3) {
    const _0x5cce9a = _0x134a13;
    if (_0x2dfca3[_0x5cce9a(269)] === _0x5cce9a(209)) {
      console[_0x5cce9a(216)]("Alarm triggered at " + new Date()[_0x5cce9a(240)]());
      chrome[_0x5cce9a(250)][_0x5cce9a(205)]({
        url: _0x5cce9a(251)
      }, function (_0xbb5eca) {
        const _0x460c0f = _0x5cce9a;
        _0xbb5eca[_0x460c0f(182)](_0x2cb917 => {
          const _0x512ce1 = _0x460c0f;
          if (_0x2cb917[_0x512ce1(234)].includes(_0x512ce1(237))) {
            console.log(_0x512ce1(283) + _0x2cb917.id + ": " + _0x2cb917[_0x512ce1(234)]);
            chrome[_0x512ce1(250)][_0x512ce1(277)](_0x2cb917.id);
          }
        });
      });
      hourlyLoop[_0x5cce9a(184)]();
    }
  });
  chrome[_0x134a13(246)][_0x134a13(266)][_0x134a13(194)](function () {
    let _0x4277ef = async function () {
      const _0xe04738 = _0x5191;
      let _0x2d176a = await chrome[_0xe04738(188)][_0xe04738(272)][_0xe04738(241)](["hkticketkiller_success_tabId", _0xe04738(195)]);
      if (!_0x2d176a) {
        return;
      }
      let _0x7457cc = _0x2d176a[_0xe04738(201)];
      let _0x5a7cb9 = _0x2d176a[_0xe04738(195)];
      if (_0x7457cc) {
        await chrome.tabs[_0xe04738(267)](_0x7457cc, {
          highlighted: true
        });
      }
      if (_0x5a7cb9) {
        await chrome[_0xe04738(243)].update(_0x5a7cb9, {
          focused: true
        });
      }
    };
    _0x4277ef();
  });
  chrome[_0x134a13(243)][_0x134a13(230)][_0x134a13(194)](() => {
    const _0x488095 = _0x134a13;
    console.log(_0x488095(230));
    chrome.storage[_0x488095(206)].set({
      hkticketkiller_disabled: false,
      hkticketkiller_enabled: false
    }, () => {
      checkDeadline();
    });
  });
  chrome.runtime[_0x134a13(284)].addListener(function (_0x2b2455, _0x283bff, _0x2fb6f1) {
    const _0x41a73d = _0x134a13;
    console[_0x41a73d(216)](_0x41a73d(253), _0x2b2455);
    if (_0x2b2455[_0x41a73d(222)] === _0x41a73d(271)) {
      openNewTab(_0x2b2455.url);
    } else if (_0x2b2455[_0x41a73d(222)]) {
      sendMsg(_0x2b2455.action);
    }
    return true;
  });
  let forceReload = async function (_0x4c9b0d) {
    const _0x249380 = _0x134a13;
    console[_0x249380(216)](_0x249380(259), _0x4c9b0d);
    console[_0x249380(216)](stopForceReloadIds);
    if (stopForceReloadIds[_0x249380(263)](_0x4c9b0d)) {
      console[_0x249380(216)](_0x249380(224), _0x4c9b0d);
      sendResponse(false);
      return;
    }
    await chrome[_0x249380(250)][_0x249380(277)](_0x4c9b0d, {
      bypassCache: true
    });
    return true;
  };
  chrome[_0x134a13(192)][_0x134a13(190)][_0x134a13(194)](function (_0x280c37, _0x262345, _0x374403) {
    const _0x5e1e = _0x134a13;
    console[_0x5e1e(216)](_0x262345[_0x5e1e(189)] ? "msg received from a content script:" + _0x262345.tab[_0x5e1e(234)] : "msg received from the extension");
    console.log(_0x262345);
    console[_0x5e1e(216)](_0x280c37);
    if (_0x280c37[_0x5e1e(222)] === _0x5e1e(208)) {
      chrome[_0x5e1e(243)][_0x5e1e(267)](_0x262345[_0x5e1e(189)][_0x5e1e(238)], {
        state: "maximized"
      });
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(274)) {
      let _0x523c7f = _0x262345.tab.windowId;
      if (doNotChangeWindowIds[_0x5e1e(263)](_0x523c7f)) {
        _0x374403(false);
        return;
      }
      if (startedWindowIds.includes(_0x523c7f)) {
        let _0x114f01 = startedWindowIds[_0x5e1e(228)](_0x523c7f);
        if (_0x114f01 > 0) {
          startedWindowIds[_0x5e1e(218)](_0x114f01, 1);
        }
      } else {
        _0x374403(false);
        return;
      }
      _0x374403(true);
      doNotChangeWindowIds[_0x5e1e(257)](_0x523c7f);
      chrome.system[_0x5e1e(214)][_0x5e1e(179)](function (_0x4a8a24) {
        const _0x27d440 = _0x5e1e;
        if (_0x4a8a24[_0x27d440(199)] > 0) {
          let _0x325cef = _0x4a8a24[0][_0x27d440(252)][_0x27d440(229)];
          let _0x47873e = Math[_0x27d440(239)](_0x325cef * 0.5);
          chrome[_0x27d440(243)][_0x27d440(267)](_0x523c7f, {
            drawAttention: true,
            width: _0x47873e,
            height: _0x280c37.height,
            left: 0,
            top: 0,
            state: _0x27d440(203)
          });
          if (_0x280c37[_0x27d440(261)] === _0x27d440(225)) {
            chrome[_0x27d440(250)][_0x27d440(233)](_0x262345[_0x27d440(189)].id, 0.5);
          } else {
            chrome[_0x27d440(250)][_0x27d440(233)](_0x262345[_0x27d440(189)].id, 0.65);
          }
        }
      });
      let _0x187d5d = async function (_0x2032b0) {
        const _0x24b9b7 = _0x5e1e;
        await chrome[_0x24b9b7(188)][_0x24b9b7(272)][_0x24b9b7(213)]({
          hkticketkiller_success_tabId: _0x2032b0.id,
          hkticketkiller_success_windowId: _0x2032b0.windowId
        });
        await chrome[_0x24b9b7(246)].create(_0x24b9b7(207), {
          title: "HKticketkiller",
          message: _0x24b9b7(196),
          buttons: [{
            title: "查看"
          }],
          iconUrl: chrome[_0x24b9b7(192)][_0x24b9b7(244)]("images/1.png"),
          type: _0x24b9b7(275)
        });
      };
      _0x187d5d(_0x262345[_0x5e1e(189)]);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(248)) {
      let _0x1534b2 = _0x262345[_0x5e1e(189)].windowId;
      if (!startedWindowIds.includes(_0x1534b2)) {
        startedWindowIds[_0x5e1e(257)](_0x1534b2);
      }
      _0x374403(true);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(180)) {
      checkDeadline(_0x262345);
      _0x374403(true);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(265)) {
      chrome.storage[_0x5e1e(206)].get([_0x5e1e(220)]).then(_0x3b01b2 => {
        const _0x349eaf = _0x5e1e;
        console[_0x349eaf(216)](_0x349eaf(176) + _0x3b01b2[_0x349eaf(220)]);
        let _0x152bcd = _0x3b01b2[_0x349eaf(220)];
        if (versionTest) {
          _0x152bcd = 1735660800;
        }
        if (_0x262345[_0x349eaf(189)] && _0x262345[_0x349eaf(189)].id) {
          chrome[_0x349eaf(250)][_0x349eaf(202)](_0x262345[_0x349eaf(189)].id, {
            action: _0x349eaf(270),
            deadline: _0x152bcd
          });
        } else {
          chrome[_0x349eaf(192)].sendMessage({
            action: "getDeadlineCallback",
            deadline: _0x152bcd
          });
        }
        _0x374403({
          deadline: _0x152bcd
        });
      }).catch(_0x45a010 => {
        const _0x207ed6 = _0x5e1e;
        console[_0x207ed6(216)](_0x207ed6(227), _0x45a010);
      });
    } else if (_0x280c37.action === "getDeadlineFromKey") {
      let _0x1378ee = backendDomain + "/app/card/login?card=" + _0x280c37.key;
      fetch(_0x1378ee, {
        mode: _0x5e1e(235)
      })[_0x5e1e(256)](_0x4c8cbf => _0x4c8cbf[_0x5e1e(185)]()).then(_0x47b33a => {
        const _0x84d600 = _0x5e1e;
        console[_0x84d600(216)](_0x84d600(281), _0x47b33a);
        if (_0x47b33a && _0x47b33a[_0x84d600(232)]) {
          throw _0x47b33a.error;
        }
        if (!_0x47b33a) {
          _0x374403(null);
        } else {
          chrome[_0x84d600(188)][_0x84d600(206)][_0x84d600(213)]({
            hkticketkiller_deadline:_0x47b33a['data']['unixtime'],
            hkticketkiller_enabled: false,
            hkticketkiller_disabled: false,
            hkticketkiller_key: _0x280c37[_0x84d600(183)]
          })[_0x84d600(256)](() => {
            checkDeadline(_0x262345);
          });
          _0x374403({
            deadline: _0x47b33a.data.unixtime
          });
        }
      })[_0x5e1e(186)](_0x35f64d => {
        const _0x584914 = _0x5e1e;
        console[_0x584914(216)](_0x584914(227), _0x35f64d);
        let _0x5b63f0 = {
          action: "checkDeadlineCallback",
          disable: true,
          error: _0x35f64d[_0x584914(249)]
        };
        if (_0x262345[_0x584914(189)] && _0x262345[_0x584914(189)].id) {
          chrome.tabs[_0x584914(202)](_0x262345.tab.id, _0x5b63f0);
        } else {
          chrome[_0x584914(192)][_0x584914(202)](_0x5b63f0);
        }
      });
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(193)) {
      chrome[_0x5e1e(188)][_0x5e1e(206)][_0x5e1e(213)]({
        hkticketkiller_deadline: _0x280c37[_0x5e1e(200)]
      });
      _0x374403(true);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(280)) {
      chrome[_0x5e1e(188)][_0x5e1e(206)][_0x5e1e(213)]({
        hkticketkiller_options: _0x280c37[_0x5e1e(254)]
      });
      _0x374403(true);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(282)) {
      chrome[_0x5e1e(188)][_0x5e1e(206)].get(["hkticketkiller_options"])[_0x5e1e(256)](_0x59274c => {
        const _0x56c501 = _0x5e1e;
        console[_0x56c501(216)](_0x59274c.hkticketkiller_options);
        if (_0x262345[_0x56c501(189)] && _0x262345[_0x56c501(189)].id) {
          chrome[_0x56c501(250)].sendMessage(_0x262345[_0x56c501(189)].id, {
            action: _0x56c501(215),
            options: _0x59274c.hkticketkiller_options
          });
        } else {
          chrome.runtime.sendMessage({
            action: _0x56c501(215),
            options: _0x59274c[_0x56c501(264)]
          });
        }
        _0x374403(_0x59274c[_0x56c501(264)]);
      });
    } else if (_0x280c37[_0x5e1e(222)] === "goToSettings") {
      let _0x501f78 = settingsPage;
      if (_0x280c37[_0x5e1e(278)]) {
        _0x501f78 = settingsPage + "?page=" + _0x280c37.page;
      }
      openNewTab(_0x501f78);
      _0x374403(true);
    } else if (_0x280c37.action === _0x5e1e(259)) {
      const _0x361809 = stopForceReloadIds[_0x5e1e(228)](_0x262345.tab.id);
      if (_0x361809 > -1) {
        stopForceReloadIds[_0x5e1e(218)](_0x361809, 1);
      }
      // TOLOOK
      setTimeout(() => {
        const _0x4692ba = _0x5e1e;
        forceReload(_0x262345[_0x4692ba(189)].id);
      }, _0x280c37[_0x5e1e(210)] || 100);
      _0x374403(true);
    } else if (_0x280c37[_0x5e1e(222)] === _0x5e1e(212)) {
      stopForceReloadIds.push(_0x262345[_0x5e1e(189)].id);
      console[_0x5e1e(216)]("stopForceReload");
      console[_0x5e1e(216)](stopForceReloadIds);
      _0x374403(true);
    }
    return true;
  });