function _0x3f50() {
    const _0x176a4f = ["7ENwQgv", "body", "getElementById", "277213JaZBJs", "none", "toggle-", "13360192ddXpBv", "toLocaleString", "activate_input", "toggle_urbtix_autofill", "display", "inactive", "append", "innerHTML", "speed", "--check-toggle", "cityline", "setAttribute", "error", "setDeadline", "checked", "1800048htOdWv", "change", "key", "runtime", "setProperty", "outdated", "urbtix", "div", "mytoggle", "desc", "enable", "14716755ClLler", "href", "style", "all_settings", "width", "快達票自動刷新速度: ", "options_container", "addListener", "querySelector", "flex", "check_key_url", "random", "toggle_cityline_autofill", "logo", "未啟用", "6709590KzJemK", "getOptions", "請更新產品金鑰", "title", "已過期", "options", "--scale", "749379hLlZnH", "createElement", "#be1931", "disable", "log", "type", "appendChild", "action", "deadline", "getBoundingClientRect", "491468BvTZXX", "value", "onclick", "25LXvquZ", "oninput", "hkticketing", "options_hkticketing_range_desc", "https://hkticketkiller.com/check_key?key=", "paymentInfo", ":root", "substring", "getDeadlineFromKey", "classList", "addEventListener", "金鑰無效，請再試一次", "updateOptions", "goToSettings", "checkDeadline", "response", "zh-HK", "sendMessage", "innerText", "有效期至: "];
    _0x3f50 = function () {
      return _0x176a4f;
    };
    return _0x3f50();
  }
  function _0x3f2b(_0x414d49, _0x182781) {
    const _0x3f50ec = _0x3f50();
    _0x3f2b = function (_0x3f2b6a, _0x5be47b) {
      _0x3f2b6a = _0x3f2b6a - 264;
      let _0x1c981e = _0x3f50ec[_0x3f2b6a];
      return _0x1c981e;
    };
    return _0x3f2b(_0x414d49, _0x182781);
  }
  const _0x94d625 = _0x3f2b;
  (function (_0x5763a2, _0x52ad4b) {
    const _0xbd20ce = _0x3f2b;
    const _0x2de72a = _0x5763a2();
    while (true) {
      try {
        const _0xff7879 = parseInt(_0xbd20ce(340)) / 1 + parseInt(_0xbd20ce(271)) / 2 + parseInt(_0xbd20ce(304)) / 3 + parseInt(_0xbd20ce(314)) / 4 * (parseInt(_0xbd20ce(317)) / 5) + -parseInt(_0xbd20ce(297)) / 6 + parseInt(_0xbd20ce(337)) / 7 * (-parseInt(_0xbd20ce(343)) / 8) + parseInt(_0xbd20ce(282)) / 9;
        if (_0xff7879 === _0x52ad4b) {
          break;
        } else {
          _0x2de72a.push(_0x2de72a.shift());
        }
      } catch (_0x1ee30c) {
        _0x2de72a.push(_0x2de72a.shift());
      }
    }
  })(_0x3f50, 888271);
  let scale = 1;
  let baseWidth = 300;
  let ExtensionStatus = {
    inactive: _0x94d625(296),
    active: "已啟用",
    outdated: _0x94d625(301)
  };
  let title = document[_0x94d625(339)](_0x94d625(300));
  let desc = document[_0x94d625(339)](_0x94d625(280));
  let activateInput = document.getElementById(_0x94d625(345));
  let activateButton = document.getElementById("activate_button");
  let mainContainer = document.getElementById("main_container");
  let loadingContainer = document.getElementById("loading_container");
  let logo = document.getElementById(_0x94d625(295));
  let checkKeyUrl = document[_0x94d625(339)](_0x94d625(292));
  let currentStatus = ExtensionStatus.inactive;
  let deadline;
  let options = {
    hkticketing: {
      speed: 3
    }
  };
  let showLoadingContainer = function (_0x2cf4e5) {
    const _0x2323d9 = _0x94d625;
    if (_0x2cf4e5) {
      mainContainer.style[_0x2323d9(347)] = _0x2323d9(341);
      loadingContainer.style[_0x2323d9(347)] = "flex";
    } else {
      mainContainer.style[_0x2323d9(347)] = _0x2323d9(291);
      loadingContainer[_0x2323d9(284)][_0x2323d9(347)] = _0x2323d9(341);
    }
  };
  let getDeadlineFromKey = async function (_0x2e0e0f) {
    const _0x3c49c6 = _0x94d625;
    let _0x143e4b = await chrome[_0x3c49c6(274)][_0x3c49c6(334)]({
      action: _0x3c49c6(325),
      key: _0x2e0e0f
    });
    console.log(_0x3c49c6(332), _0x143e4b);
    if (_0x143e4b) {
      return _0x143e4b[_0x3c49c6(312)];
    }
    return null;
  };
  let initActivateButton = function () {
    const _0xb5f452 = _0x94d625;
    activateButton[_0xb5f452(316)] = async function () {
      const _0x1e0e06 = _0xb5f452;
      showLoadingContainer(true);
      try {
        if (!activateInput.value) {
          throw "未輸入金鑰，請再試一次";
        }
        checkKeyUrl.setAttribute(_0x1e0e06(283), _0x1e0e06(321) + activateInput.value);
        let _0x39dbf1 = await getDeadlineFromKey(activateInput[_0x1e0e06(315)]);
        return;
        if (!_0x39dbf1) {
          throw _0x1e0e06(328);
        }
        await chrome[_0x1e0e06(274)][_0x1e0e06(334)]({
          action: _0x1e0e06(269),
          deadline: _0x39dbf1
        });
        setStatus(await getStatus());
      } catch (_0xb42900) {
        console[_0x1e0e06(308)](_0xb42900);
        desc.innerText = JSON.stringify(_0xb42900);
      }
      return;
      activateInput[_0x1e0e06(315)] = "";
      showLoadingContainer(false);
    };
  };
  let initOptionsButton = function () {
    const _0x1d0069 = _0x94d625;
    let _0x5099d1 = document[_0x1d0069(339)](_0x1d0069(285));
    _0x5099d1[_0x1d0069(316)] = async function () {
      const _0x4e19d8 = _0x1d0069;
      let _0x2a999f = await chrome[_0x4e19d8(274)][_0x4e19d8(334)]({
        action: "goToSettings"
      });
      return;
      let _0x593501 = document[_0x4e19d8(339)](_0x4e19d8(288));
      _0x593501[_0x4e19d8(284)][_0x4e19d8(347)] = _0x4e19d8(291);
      mainContainer.style[_0x4e19d8(347)] = _0x4e19d8(341);
    };
  };
  let createToggle = function (_0x2dd095) {
    const _0x885c7 = _0x94d625;
    let _0x3c9210 = _0x885c7(342) + Math[_0x885c7(293)]().toString(36)[_0x885c7(324)](2, 16);
    let _0x76b092 = "togid" + Math[_0x885c7(293)]().toString(24)[_0x885c7(324)](2, 16);
    const _0x198baf = document[_0x885c7(305)]("LABEL");
    const _0x434d43 = document[_0x885c7(305)]("input");
    _0x434d43[_0x885c7(267)](_0x885c7(309), "checkbox");
    _0x434d43[_0x885c7(267)]("id", _0x3c9210);
    _0x434d43[_0x885c7(326)].add("toG");
    const _0xdf017c = document[_0x885c7(305)](_0x885c7(278));
    _0xdf017c[_0x885c7(267)]("id", _0x76b092);
    _0xdf017c[_0x885c7(284)].setProperty(_0x885c7(265), _0x885c7(306));
    _0x198baf.append(_0x434d43);
    _0x198baf[_0x885c7(349)](_0xdf017c);
    _0xdf017c[_0x885c7(326)].add(_0x885c7(279));
    _0x2dd095[_0x885c7(310)](_0x198baf);
    return _0x3c9210;
  };
  let initOptions = async function () {
    const _0x459236 = _0x94d625;
    let _0x171231 = document[_0x459236(339)](_0x459236(288));
    _0x171231[_0x459236(284)][_0x459236(347)] = "flex";
    let _0x4464a3 = document[_0x459236(339)]("options_hkticketing_range");
    let _0x5a8a3e = document[_0x459236(339)](_0x459236(320));
    if (!options) {
      options = {};
    }
    if (options[_0x459236(319)]) {
      _0x4464a3.value = options.hkticketing[_0x459236(264)];
      _0x5a8a3e[_0x459236(335)] = _0x459236(287) + _0x4464a3[_0x459236(315)] + "秒";
    }
    _0x4464a3[_0x459236(318)] = function () {
      const _0x25cbd4 = _0x459236;
      console[_0x25cbd4(308)](this[_0x25cbd4(315)]);
      _0x5a8a3e[_0x25cbd4(335)] = "快達票自動刷新速度: " + this.value + "秒";
      if (!options[_0x25cbd4(319)]) {
        options[_0x25cbd4(319)] = {};
      }
      options.hkticketing[_0x25cbd4(264)] = this[_0x25cbd4(315)];
      chrome[_0x25cbd4(274)][_0x25cbd4(334)]({
        action: "updateOptions",
        options: options
      });
    };
    let _0x2ace8a = document.getElementById(_0x459236(346));
    let _0x340cbc = createToggle(_0x2ace8a);
    let _0x2bbb20 = document[_0x459236(339)](_0x340cbc);
    if (options[_0x459236(277)] && options.urbtix.paymentInfo) {
      _0x2bbb20[_0x459236(270)] = options[_0x459236(277)][_0x459236(322)][_0x459236(281)];
    }
    _0x2bbb20[_0x459236(327)](_0x459236(272), function () {
      const _0x2528c2 = _0x459236;
      if (!options[_0x2528c2(277)]) {
        options[_0x2528c2(277)] = {};
      }
      if (!options[_0x2528c2(277)][_0x2528c2(322)]) {
        options.urbtix[_0x2528c2(322)] = {};
      }
      options.urbtix[_0x2528c2(322)][_0x2528c2(281)] = _0x2bbb20[_0x2528c2(270)];
      chrome[_0x2528c2(274)][_0x2528c2(334)]({
        action: "updateOptions",
        options: options
      });
      if (options[_0x2528c2(277)][_0x2528c2(322)].enable) {
        chrome[_0x2528c2(274)][_0x2528c2(334)]({
          action: _0x2528c2(330),
          page: _0x2528c2(277)
        });
      }
    });
    let _0x230898 = document[_0x459236(339)](_0x459236(294));
    let _0x1d2f20 = createToggle(_0x230898);
    let _0x3a645a = document[_0x459236(339)](_0x1d2f20);
    if (options.cityline && options[_0x459236(266)][_0x459236(322)]) {
      _0x3a645a[_0x459236(270)] = options[_0x459236(266)][_0x459236(322)][_0x459236(281)];
    }
    _0x3a645a[_0x459236(327)]("change", function () {
      const _0x3adddf = _0x459236;
      if (!options.cityline) {
        options[_0x3adddf(266)] = {};
      }
      if (!options[_0x3adddf(266)][_0x3adddf(322)]) {
        options[_0x3adddf(266)].paymentInfo = {};
      }
      options.cityline[_0x3adddf(322)][_0x3adddf(281)] = _0x3a645a.checked;
      chrome[_0x3adddf(274)][_0x3adddf(334)]({
        action: _0x3adddf(329),
        options: options
      });
      if (options.cityline[_0x3adddf(322)][_0x3adddf(281)]) {
        chrome.runtime.sendMessage({
          action: "goToSettings",
          page: "cityline"
        });
      }
    });
    initOptionsButton();
  };
  let setStatus = function (_0x315d05) {
    const _0x22e7b3 = _0x94d625;
    currentStatus = _0x315d05;
    if (currentStatus === ExtensionStatus[_0x22e7b3(276)]) {
      let _0x372f33 = new Date(deadline * 1000);
      title[_0x22e7b3(335)] = currentStatus + " (" + _0x372f33[_0x22e7b3(344)]("zh-HK") + ")";
      desc.innerText = _0x22e7b3(299);
      activateButton[_0x22e7b3(350)] = "更新";
    } else if (currentStatus === ExtensionStatus.active) {
      let _0x6e5b5d = new Date(deadline * 1000);
      title[_0x22e7b3(335)] = currentStatus;
      desc.innerText = _0x22e7b3(336) + _0x6e5b5d[_0x22e7b3(344)](_0x22e7b3(333));
      activateButton[_0x22e7b3(284)].display = _0x22e7b3(341);
      activateInput[_0x22e7b3(284)].display = "none";
    }
  };
  let getDeadline = async function () {
    const _0x3e5170 = _0x94d625;
    return await chrome[_0x3e5170(274)][_0x3e5170(334)]({
      action: _0x3e5170(331)
    });
  };
  let getOptions = async function () {
    const _0x15bfd9 = _0x94d625;
    try {
      let _0x2cc92b = await chrome.runtime.sendMessage({
        action: _0x15bfd9(298)
      });
      if (_0x2cc92b) {
        options = _0x2cc92b;
      }
    } catch (_0x164f83) {
      console.log(_0x164f83);
    }
  };
  let handleScale = function () {
    const _0x4f316a = _0x94d625;
    let _0x21e046 = screen.width;
    let _0x1b3877 = document.documentElement[_0x4f316a(313)]()[_0x4f316a(286)];
    scale = _0x1b3877 / baseWidth;
    document[_0x4f316a(338)][_0x4f316a(284)][_0x4f316a(286)] = scale * 300 + "px";
    var _0x4aba75 = document[_0x4f316a(290)](_0x4f316a(323));
    _0x4aba75[_0x4f316a(284)][_0x4f316a(275)](_0x4f316a(303), scale);
  };
  let main = async function () {
    handleScale();
    initActivateButton();
    getDeadline();
    return true;
  };
  main();
  chrome[_0x94d625(274)].onMessage[_0x94d625(289)](async function (_0x1657c1, _0x2805cf, _0x3366bb) {
    const _0x4aab39 = _0x94d625;
    if (_0x1657c1[_0x4aab39(311)] === "checkDeadlineCallback") {
      deadline = _0x1657c1[_0x4aab39(312)];
      if (_0x1657c1.key) {
        checkKeyUrl[_0x4aab39(267)](_0x4aab39(283), _0x4aab39(321) + _0x1657c1[_0x4aab39(273)]);
        checkKeyUrl[_0x4aab39(335)] = "剩餘金鑰使用次數";
      }
      if (_0x1657c1[_0x4aab39(268)]) {
        setStatus(ExtensionStatus[_0x4aab39(348)]);
        desc[_0x4aab39(335)] = _0x1657c1[_0x4aab39(268)];
      } else if (!deadline) {
        setStatus(ExtensionStatus[_0x4aab39(348)]);
      } else if (_0x1657c1[_0x4aab39(307)]) {
        setStatus(ExtensionStatus[_0x4aab39(276)]);
      } else {
        setStatus(ExtensionStatus.active);
        getOptions();
      }
      showLoadingContainer(false);
      _0x3366bb(true);
    } else if (_0x1657c1[_0x4aab39(311)] === "getOptionsCallback") {
      options = _0x1657c1[_0x4aab39(302)];
      initOptions();
      _0x3366bb(true);
    }
    return true;
  });