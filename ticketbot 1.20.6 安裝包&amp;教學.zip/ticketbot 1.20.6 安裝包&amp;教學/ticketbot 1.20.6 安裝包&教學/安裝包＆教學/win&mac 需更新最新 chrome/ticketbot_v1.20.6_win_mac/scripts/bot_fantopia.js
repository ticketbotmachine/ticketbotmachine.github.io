const _0x29c1ea = _0x45e0;
(function (_0x5bc0c2, _0x5157f3) {
  const _0x3489fa = _0x45e0;
  const _0x3c7415 = _0x5bc0c2();
  while (true) {
    try {
      const _0x5d94b6 = -parseInt(_0x3489fa(384)) / 1 * (parseInt(_0x3489fa(458)) / 2) + parseInt(_0x3489fa(418)) / 3 + parseInt(_0x3489fa(467)) / 4 + parseInt(_0x3489fa(410)) / 5 + parseInt(_0x3489fa(383)) / 6 + parseInt(_0x3489fa(425)) / 7 * (parseInt(_0x3489fa(411)) / 8) + -parseInt(_0x3489fa(465)) / 9 * (parseInt(_0x3489fa(444)) / 10);
      if (_0x5d94b6 === _0x5157f3) {
        break;
      } else {
        _0x3c7415.push(_0x3c7415.shift());
      }
    } catch (_0x4e16e2) {
      _0x3c7415.push(_0x3c7415.shift());
    }
  }
})(_0x5089, 857121);
let hkticketkiller;
let hkticketkiller_path = "scripts/ticketbot.js";
let mainInterval;
let enabled = true;
let fantopiaOptions = {
  autofillMembershipNumber: {
    enable: false,
    membershipNumber: ""
  },
  addCart: {
    enable: false,
    dateSelectionRule: _0x29c1ea(476),
    priceSelectionRule: "由下至上",
    qty: 2,
    ignore: _0x29c1ea(434),
    reloadDelay: 10
  }
};
let debugLog = function (_0xcd4bcb) {
  const _0x1a4bb9 = _0x29c1ea;
  console[_0x1a4bb9(402)](_0x1a4bb9(487), _0xcd4bcb);
};
let importHkticketkillerFuncs = async function () {
  const _0x185ca6 = _0x29c1ea;
  const _0x26a6a4 = chrome[_0x185ca6(475)][_0x185ca6(419)](hkticketkiller_path);
  hkticketkiller = await import(_0x26a6a4);
};
let init = async function () {
  const _0x46cf36 = _0x29c1ea;
  debugLog(_0x46cf36(378));
  await importHkticketkillerFuncs();
  mainInterval = // TOLOOK
  setInterval(main, 500);
  chrome.runtime[_0x46cf36(462)]({
    action: _0x46cf36(421)
  });
  chrome[_0x46cf36(475)][_0x46cf36(462)]({
    action: _0x46cf36(446)
  });
};
let tools = {
  secondToTime: function (_0x15616c) {
    const _0x2559ae = _0x29c1ea;
    return new Date(_0x15616c * 1000)[_0x2559ae(427)]()[_0x2559ae(398)](14, 19);
  },
  createDivWithClass: function (_0x4e343d) {
    const _0xbc77d6 = _0x29c1ea;
    let _0x1dbfde = document[_0xbc77d6(397)](_0xbc77d6(490));
    for (let _0x12c7bd = 0; _0x12c7bd < _0x4e343d[_0xbc77d6(430)]; _0x12c7bd++) {
      _0x1dbfde.classList[_0xbc77d6(429)](_0x4e343d[_0x12c7bd]);
    }
    return _0x1dbfde;
  },
  getRandNum: function (_0xbe588b, _0x4789ff) {
    const _0x188cf6 = _0x29c1ea;
    return Math[_0x188cf6(494)](Math[_0x188cf6(403)]() * (_0x4789ff - _0xbe588b + 1)) + _0xbe588b;
  }
};
let clickNextbutton = function () {
  const _0x347bbc = _0x29c1ea;
  let _0x1d0aa2 = document[_0x347bbc(401)]("button.btn-linear-bg");
  if (!_0x1d0aa2) {
    return;
  }
  _0x1d0aa2[_0x347bbc(393)]();
  const _0x48e7d9 = tools.getRandNum(1000, 2000);
  // TOLOOK
  setTimeout(clickNextbutton, _0x48e7d9);
};
const PresaleMemberCodeHelper = {
  firstAttempt: false,
  run: function () {
    const _0x556a1f = _0x29c1ea;
    if (!fantopiaOptions[_0x556a1f(382)][_0x556a1f(396)]) {
      return;
    }
    if (!this.firstAttempt) {
      let _0x45e088 = document[_0x556a1f(401)](_0x556a1f(495));
      if (!_0x45e088) {
        return;
      }
      _0x45e088.focus();
      _0x45e088[_0x556a1f(414)] = fantopiaOptions[_0x556a1f(382)][_0x556a1f(450)] || "";
      _0x45e088.blur();
      _0x45e088[_0x556a1f(389)](new Event(_0x556a1f(388), {
        bubbles: true
      }));
      this[_0x556a1f(449)] = true;
    }
    let _0x5944c7 = document[_0x556a1f(401)]("form button");
    if (_0x5944c7) {
      _0x5944c7[_0x556a1f(393)]();
    }
  }
};
const PurchasePageAddCartHelper = {
  priceSelected: false,
  dateSelected: false,
  qtySelected: false,
  complete: false,
  lastTimestamp: null,
  interval: 500,
  scheduledReload: false,
  reloadDelay: null,
  run: function () {
    const _0x252d6f = _0x29c1ea;
    if (this[_0x252d6f(461)]) {
      return;
    } else if (!fantopiaOptions[_0x252d6f(435)][_0x252d6f(396)] || !fantopiaOptions[_0x252d6f(435)][_0x252d6f(399)]) {
      return;
    }
    if (!this[_0x252d6f(391)] && fantopiaOptions[_0x252d6f(435)].reloadDelay) {
      chrome[_0x252d6f(475)][_0x252d6f(462)]({
        action: _0x252d6f(468),
        delay: fantopiaOptions[_0x252d6f(435)][_0x252d6f(482)] * 1000
      });
      this[_0x252d6f(391)] = true;
    }
    let _0x4883c0 = Date[_0x252d6f(420)]();
    if (this[_0x252d6f(437)] && _0x4883c0 - this[_0x252d6f(437)] < this.interval) {
      return;
    }
    this[_0x252d6f(437)] = _0x4883c0;
    debugLog(_0x252d6f(439));
    if (!this[_0x252d6f(432)]) {
      let _0x48db49 = document[_0x252d6f(407)](_0x252d6f(451));
      let _0x2081cf = [];
      _0x48db49[_0x252d6f(443)](_0x1837dd => {
        _0x2081cf.push(_0x1837dd);
      });
      while (_0x2081cf.length > 0) {
        let _0x6e5853;
        if (fantopiaOptions[_0x252d6f(435)][_0x252d6f(431)] === _0x252d6f(459)) {
          _0x6e5853 = _0x2081cf[_0x252d6f(448)]();
        } else if (fantopiaOptions[_0x252d6f(435)].dateSelectionRule === _0x252d6f(476)) {
          _0x6e5853 = _0x2081cf[_0x252d6f(390)]();
        } else {
          _0x6e5853 = _0x2081cf[_0x252d6f(424)](Math.floor(Math[_0x252d6f(403)]() * _0x2081cf.length), 1)[0];
        }
        _0x6e5853.click();
        break;
      }
      debugLog("select date");
      this[_0x252d6f(432)] = true;
      return;
    }
    if (!this[_0x252d6f(492)]) {
      let _0x1e0845 = document[_0x252d6f(407)](_0x252d6f(483))[1];
      if (!_0x1e0845) {
        let _0x4bb280 = document[_0x252d6f(407)](_0x252d6f(426));
        let _0x1fc536 = [];
        _0x4bb280[_0x252d6f(443)](_0x4ea81a => {
          _0x1fc536.push(_0x4ea81a);
        });
        let _0x5c55b3 = fantopiaOptions[_0x252d6f(435)][_0x252d6f(381)];
        let _0x3da20f = [];
        if (_0x5c55b3) {
          _0x5c55b3 = _0x5c55b3[_0x252d6f(422)]("，", ",");
          _0x3da20f = _0x5c55b3.split(",");
        }
        _0x3da20f[_0x252d6f(485)](_0x252d6f(452));
        _0x3da20f.push(_0x252d6f(456));
        _0x3da20f.push("Reserve");
        let _0x245b3a;
        while (_0x1fc536[_0x252d6f(430)] > 0) {
          if (fantopiaOptions[_0x252d6f(435)].priceSelectionRule === _0x252d6f(423)) {
            _0x245b3a = _0x1fc536[_0x252d6f(448)]();
          } else if (fantopiaOptions[_0x252d6f(435)][_0x252d6f(477)] === _0x252d6f(412)) {
            _0x245b3a = _0x1fc536.pop();
          } else {
            _0x245b3a = _0x1fc536.splice(Math.floor(Math[_0x252d6f(403)]() * _0x1fc536[_0x252d6f(430)]), 1)[0];
          }
          if (_0x3da20f[_0x252d6f(469)](_0x1edad6 => _0x245b3a[_0x252d6f(493)][_0x252d6f(433)](_0x1edad6.trim()))) {
            _0x245b3a = null;
          } else {
            _0x245b3a[_0x252d6f(393)]();
            debugLog(_0x252d6f(453));
            this.priceSelected = true;
            break;
          }
        }
        if (!_0x245b3a) {
          debugLog(_0x252d6f(474));
          window[_0x252d6f(413)][_0x252d6f(415)] = window[_0x252d6f(413)][_0x252d6f(415)];
        }
        return;
      }
      for (let _0x4f1a51 = 0; _0x4f1a51 < fantopiaOptions[_0x252d6f(435)][_0x252d6f(399)]; _0x4f1a51++) {
        _0x1e0845[_0x252d6f(393)]();
      }
      this[_0x252d6f(492)] = true;
    }
    if (PurchasePageRetryHelper[_0x252d6f(473)] !== null) {
      PurchasePageRetryHelper[_0x252d6f(473)].click();
      this[_0x252d6f(461)] = true;
    }
  }
};
const PurchasePageRetryHelper = {
  purchaseButton: null,
  retryButton: null,
  createRetryButton: function () {
    const _0x1ba8c5 = _0x29c1ea;
    let _0x2c9fbb = document.createElement("button");
    _0x2c9fbb.id = "hkticketkiller-auto-retry";
    _0x2c9fbb.classList[_0x1ba8c5(429)](_0x1ba8c5(472), _0x1ba8c5(387), "overflow-hidden", _0x1ba8c5(394), _0x1ba8c5(489), "btn-linear-bg", _0x1ba8c5(416), _0x1ba8c5(484), _0x1ba8c5(385), "font-semibold");
    _0x2c9fbb[_0x1ba8c5(493)] = "Auto retry";
    _0x2c9fbb[_0x1ba8c5(479)] = function () {
      const _0x3c66d6 = _0x1ba8c5;
      if (_0x2c9fbb[_0x3c66d6(417)].started !== _0x3c66d6(392)) {
        _0x2c9fbb[_0x3c66d6(417)][_0x3c66d6(404)] = "yes";
        _0x2c9fbb[_0x3c66d6(493)] = "Stop";
        PurchasePageRetryHelper[_0x3c66d6(471)]();
      } else {
        debugLog(_0x2c9fbb.dataset.stopAuto);
        if (_0x2c9fbb.dataset[_0x3c66d6(409)] === _0x3c66d6(392)) {
          debugLog(_0x3c66d6(380));
          _0x2c9fbb[_0x3c66d6(417)][_0x3c66d6(409)] = "no";
        } else {
          debugLog(_0x3c66d6(447));
          _0x2c9fbb[_0x3c66d6(417)][_0x3c66d6(409)] = _0x3c66d6(392);
        }
        if (_0x2c9fbb[_0x3c66d6(417)][_0x3c66d6(409)] === _0x3c66d6(392)) {
          _0x2c9fbb[_0x3c66d6(493)] = _0x3c66d6(470);
        } else {
          _0x2c9fbb[_0x3c66d6(493)] = _0x3c66d6(457);
        }
      }
    };
    if (this[_0x1ba8c5(440)]) {
      this.retryButton = this.purchaseButton[_0x1ba8c5(428)][_0x1ba8c5(406)](_0x2c9fbb);
      debugLog("Created retry btn.");
    }
  },
  autoClick: function () {
    const _0x181bdc = _0x29c1ea;
    let _0x295c77 = this[_0x181bdc(473)];
    let _0x488bd9 = this[_0x181bdc(440)];
    if (!_0x295c77 || !_0x488bd9) {
      return;
    }
    let _0x456c38 = document[_0x181bdc(401)](_0x181bdc(395));
    let _0x52a740 = !!_0x456c38 && !!_0x456c38[_0x181bdc(445)] && _0x456c38[_0x181bdc(445)][_0x181bdc(386)] !== _0x181bdc(405);
    if (_0x295c77[_0x181bdc(417)].stopAuto !== _0x181bdc(392) && !_0x52a740) {
      debugLog(_0x181bdc(442));
      _0x488bd9[_0x181bdc(393)]();
    } else {
      PresaleMemberCodeHelper.run();
    }
    // TOLOOK
    setTimeout(() => {
      const _0x3a2b83 = _0x181bdc;
      PurchasePageRetryHelper[_0x3a2b83(471)]();
    }, 75);
  }
};
let onPurchasePage = function () {
  const _0x5c37cc = _0x29c1ea;
  if (!document.getElementById(_0x5c37cc(408))) {
    PurchasePageRetryHelper[_0x5c37cc(486)]();
  }
  PurchasePageAddCartHelper[_0x5c37cc(496)]();
};
let main = async function () {
  const _0x356916 = _0x29c1ea;
  if (!enabled) {
    debugLog(_0x356916(488));
    clearInterval(mainInterval);
    return;
  }
  PurchasePageRetryHelper[_0x356916(440)] = document.querySelector(_0x356916(464));
  if (PurchasePageRetryHelper.purchaseButton) {
    onPurchasePage();
  } else if (PurchasePageAddCartHelper.scheduledReload) {
    chrome[_0x356916(475)][_0x356916(462)]({
      action: _0x356916(400)
    });
    PurchasePageAddCartHelper[_0x356916(391)] = false;
  }
};
function _0x45e0(_0x422ac9, _0x4351d5) {
  const _0x50890b = _0x5089();
  _0x45e0 = function (_0x45e0ca, _0x564b2b) {
    _0x45e0ca = _0x45e0ca - 378;
    let _0x540291 = _0x50890b[_0x45e0ca];
    return _0x540291;
  };
  return _0x45e0(_0x422ac9, _0x4351d5);
}
function _0x5089() {
  const _0x32ac6f = ["Set to false", "ignore", "autofillMembershipNumber", "5281938qaBaQA", "176489ZOYJQO", "text-white", "display", "relative", "input", "dispatchEvent", "pop", "scheduledReload", "yes", "click", "w-[160px]", ".ant-modal-mask", "enable", "createElement", "substring", "qty", "stopForceReload", "querySelector", "log", "random", "started", "none", "appendChild", "querySelectorAll", "hkticketkiller-auto-retry", "stopAuto", "931915FUYGnU", "6232yQYhPm", "由下至上", "location", "value", "href", "rounded-full", "dataset", "2465724PYXMaN", "getURL", "now", "checkDeadline", "replaceAll", "由上至下", "splice", "7028FSaqdT", ".border.cursor-pointer.rounded-xl", "toISOString", "parentNode", "add", "length", "dateSelectionRule", "dateSelected", "includes", "缺貨登記,Reserve", "addCart", "options", "lastTimestamp", "addListener", "PurchasePageAddCartHelper.run()", "purchaseButton", "addEventListener", "Click purchase button.", "forEach", "230CHuGUE", "style", "getOptions", "Set to true", "shift", "firstAttempt", "membershipNumber", ".flex-wrap .flex-col", "缺貨登記", "select price", "disable", "fantopia", "缺货登记", "Stop", "8vuJnFb", "由左至右", "Key valid.", "complete", "sendMessage", "readystatechange", ".text-right button.cursor-pointer.relative.overflow-hidden", "551340KQxsNf", "message", "1205308DKYPSE", "forceReload", "some", "Auto retry", "autoClick", "cursor-pointer", "retryButton", "No available ticket", "runtime", "由右至左", "priceSelectionRule", "target", "onclick", "readyState", "getOptionsCallback", "reloadDelay", "button.bg-dark2", "text-sm", "push", "createRetryButton", "HKTicketKiller:", "disabled.", "h-11", "div", "action", "qtySelected", "innerText", "floor", "form input", "run", "onMessage", "Start Loading bot", "Bot outdated. Please update to the latest version."];
  _0x5089 = function () {
    return _0x32ac6f;
  };
  return _0x5089();
}
document.addEventListener(_0x29c1ea(463), _0x35f2b2 => {
  const _0x8d4808 = _0x29c1ea;
  if (_0x35f2b2[_0x8d4808(478)][_0x8d4808(480)] === "complete") {
    try {} catch (_0x129a14) {
      debugLog(JSON.stringify(_0x129a14));
    }
  }
});
window[_0x29c1ea(441)](_0x29c1ea(466), function (_0x11a6a9) {}, false);
chrome[_0x29c1ea(475)][_0x29c1ea(497)][_0x29c1ea(438)](async function (_0x444d5f, _0x7905f0, _0x5cd589) {
  const _0x28b0b6 = _0x29c1ea;
  if (_0x444d5f[_0x28b0b6(491)] === "checkDeadlineCallback") {
    if (_0x444d5f[_0x28b0b6(454)]) {
      enabled = false;
      debugLog(_0x28b0b6(379));
    } else {
      debugLog(_0x28b0b6(460));
    }
    _0x5cd589(true);
  } else if (_0x444d5f.action === _0x28b0b6(481)) {
    _0x5cd589(true);
    if (_0x444d5f[_0x28b0b6(436)] && _0x444d5f.options[_0x28b0b6(455)]) {
      fantopiaOptions = _0x444d5f[_0x28b0b6(436)][_0x28b0b6(455)];
    }
  }
  return true;
});
init();