let key = "cityline";
//todo
let citylineOptions = {
  paymentInfo: {},
  addCart: {
    dateRule: null
  },
  autoGoToTicketPage:false
};
//todo
let gotoInterval = setInterval(()=>{
  if(citylineOptions && citylineOptions.autoGoToTicketPage){
    if (document.querySelector('.buyTicketBox button')) {
        document.querySelector('.buyTicketBox button').click();
        clearInterval(gotoInterval);
    }else if(document.querySelector('[buyButtonLabelEn]')) {
        document.querySelector('[buyButtonLabelEn]').click();
        clearInterval(gotoInterval);
    }else if (document.querySelector('[buyButtonLabelSc]')) {
        document.querySelector('[buyButtonLabelSc]').click();
        clearInterval(gotoInterval);
    }else if (document.querySelector('[buyButtonLabelTc]')) {
        document.querySelector('[buyButtonLabelTc]').click();
        clearInterval(gotoInterval);
    }

  }
},777);
let debugLog = function (_0x4ec09f) {
  console.log("HKTicketKiller:", _0x4ec09f);
};
let tools = {
  secondToTime: function (_0x3b6e8b) {
    return new Date(_0x3b6e8b * 1000).toISOString().substring(14, 19);
  },
  createDivWithClass: function (_0x258351) {
    let _0x46636a = document.createElement("div");
    for (let _0x250f80 = 0; _0x250f80 < _0x258351.length; _0x250f80++) {
      _0x46636a.classList.add(_0x258351[_0x250f80]);
    }
    return _0x46636a;
  },
  getRandNum: function (_0x263cab, _0xdd814b) {
    return Math.floor(Math.random() * (_0xdd814b - _0x263cab + 1)) + _0x263cab;
  },
  getMobileOperatingSystem: function () {
    var _0x2a7339 = navigator.userAgent || navigator.vendor || window.opera;
    if (/windows phone/i.test(_0x2a7339)) {
      return "Windows Phone";
    }
    if (/android/i.test(_0x2a7339)) {
      return "Android";
    }
    if (/iPad|iPhone|iPod/.test(_0x2a7339) && !window.MSStream) {
      return "iOS";
    }
    return "unknown";
  }
};
let initWasm = function () {
  debugLog("initWasm");
  var _0x55e12f = {
    imports: {
      imported_func: function (_0x18ef17) {
        console.log(_0x18ef17);
      }
    }
  };
  var _0x39b1de = chrome.runtime.getURL("scripts/throttle-4.0.wasm");
  fetch(_0x39b1de).then(_0x2437fa => _0x2437fa.arrayBuffer()).then(_0x2c357b => WebAssembly.instantiate(_0x2c357b, _0x55e12f)).then(_0x45dd04 => {
    _0x45dd04.instance.exports.exported_func();
  });
};
let clickNextbutton = function () {
  let _0xd960f = document.getElementsByClassName("chooseTicketsOfferDiv")[0];
  if (!_0xd960f) {
    return;
  }
  let _0x2779dc = _0xd960f.querySelector("button");
  if (!_0x2779dc) {
    return;
  }
  _0x2779dc.click();
  const _0x3f18da = tools.getRandNum(1000, 2000);
  // TOLOOK
  setTimeout(clickNextbutton, _0x3f18da);
};
let getCurrentTime = async function () {
  let _0x19b044 = "https://worldtimeapi.org/api/timezone/Asia/Hong_Kong";
  try {
    const _0x49b8f8 = await fetch(_0x19b044);
    const _0x449b91 = await _0x49b8f8.json();
    return _0x449b91.unixtime;
  } catch (_0x5ba745) {
    return false;
  }
};
let checkDeadline = async function (_0x5ee654) {
  try {
    let _0x5e5fc5 = await getCurrentTime();
    if (!_0x5ee654 || !_0x5e5fc5 || !_0x5ee654.deadline) {
      return false;
    }
    if (_0x5e5fc5 > _0x5ee654.deadline) {
      return false;
    } else {
      return true;
    }
  } catch (_0xfe49da) {
    console.log(_0xfe49da);
    return false;
  }
};
let simulateClick = function (_0x10b1a8, _0xe0cf88) {
  if (!_0x10b1a8) {
    return;
  }
  var _0x5b48fc = _0x10b1a8.getBoundingClientRect();
  var _0x46f6bb = _0x5b48fc.left + Math.random() * _0x5b48fc.width;
  var _0x21a369 = _0x5b48fc.top + Math.random() * _0x5b48fc.height;
  var _0x2eb2d8 = new MouseEvent(_0xe0cf88, {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: _0x46f6bb,
    clientY: _0x21a369
  });
  _0x10b1a8.dispatchEvent(_0x2eb2d8);
};
let getMsDiffFromNext10am = function () {
  const _0x4848a5 = Date.now();
  const _0x52d4e1 = new Date(_0x4848a5).getHours();
  let _0x46ff07;
  if (_0x52d4e1 >= 10) {
    const _0x166d46 = new Date().setDate(new Date().getDate() + 1);
    const _0x4df341 = new Date(_0x166d46).setHours(10, 0, 0, 0);
    _0x46ff07 = _0x4df341 - _0x4848a5;
  } else {
    const _0x1dd128 = new Date().setHours(10, 0, 0, 0);
    _0x46ff07 = _0x1dd128 - _0x4848a5;
  }
  return _0x46ff07;
};
let startCountdown = function (_0x4ab3e7) {
  var _0x5e52fa = document.getElementById("countdownButton");
  _0x5e52fa.disabled = true;
  var _0x443d67 = _0x4ab3e7;
  var _0x4949cc;
  var _0x1bb1d6;
  var _0x29a418;
  var _0x254160 = // TOLOOK
  setInterval(function () {
    _0x4949cc = parseInt(_0x443d67 / 3600, 10);
    _0x1bb1d6 = parseInt(_0x443d67 % 3600 / 60, 10);
    _0x29a418 = parseInt(_0x443d67 % 60, 10);
    _0x4949cc = _0x4949cc < 10 ? "0" + _0x4949cc : _0x4949cc;
    _0x1bb1d6 = _0x1bb1d6 < 10 ? "0" + _0x1bb1d6 : _0x1bb1d6;
    _0x29a418 = _0x29a418 < 10 ? "0" + _0x29a418 : _0x29a418;
    _0x5e52fa.innerText = _0x4949cc + ":" + _0x1bb1d6 + ":" + _0x29a418;
    if (--_0x443d67 < 0) {
      clearInterval(_0x254160);
      _0x5e52fa.disabled = false;
      _0x5e52fa.innerText = "Start Countdown";
    }
  }, 1000);
};
let selectOption = function (_0x41e63b, _0x1b4e54) {
  if (_0x1b4e54 > 50) {
    debugLog("Error: unhandled options: " + _0x41e63b.length);
    return;
  }
  if (_0x41e63b.length <= 0) {
    return;
  }
  let _0x2d2ccf = _0x41e63b[0];
  let _0x137d75 = _0x2d2ccf.value;
  let _0x1cc4cc = document.querySelector("option[value=\"" + _0x137d75 + "\"]");
  if (_0x1cc4cc) {
    console.log("click", _0x1cc4cc);
    _0x1cc4cc.click();
    _0x41e63b.shift();
  }
  if (_0x41e63b.length > 0) {
    _0x41e63b[0].click();
    // TOLOOK
    setTimeout(() => {
      selectOption(_0x41e63b, _0x1b4e54++);
    }, 100);
  }
};
let autofillPaymentInfo = function () {
  debugLog("Autofill");
  let _0x354e7d = citylineOptions.paymentInfo;
  let _0x5dcdb1 = _0x354e7d.paymentMethod;
  let _0x327eb9 = document.querySelector("button[data-payment-code=\"" + _0x5dcdb1 + "\"]");
  if (_0x327eb9) {
    _0x327eb9.click();
  }
  let _0x621603 = document.querySelectorAll("#mainContainer input");
  console.log(_0x621603.id);
  for (let _0x3b0a3f = 0; _0x3b0a3f < _0x621603.length; _0x3b0a3f++) {
    let _0xb25f18 = _0x621603[_0x3b0a3f];
    if (!_0xb25f18.id) {
      continue;
    }
    let _0x43a127 = _0x354e7d[_0xb25f18.id];
    if (_0xb25f18.id === "confirmEmail") {
      _0x43a127 = _0x354e7d.email;
    }
    if (!_0x43a127) {
      continue;
    }
    _0xb25f18.focus();
    _0xb25f18.value = _0x43a127;
    _0xb25f18.blur();
  }
  let _0x9e3669 = document.getElementById("expiryMonth");
  let _0x342795 = document.getElementById("expiryYear");
  let _0x110bfd = _0x354e7d.expiry || "";
  if (_0x110bfd.includes("/")) {
    let _0x53bb24 = _0x110bfd.split("/");
    _0x9e3669.value = _0x53bb24[0];
    _0x342795.value = _0x53bb24[1];
  }
};
let onEventDetail = function () {
  debugLog("onEventDetail");
  autoAddCartHelper.autoLogin();
  let _0xc14879 = document.querySelector(".puchase-bottom .ticketCard button");
  if (_0xc14879) {
    _0xc14879.click();
  } else {
    // TOLOOK
    setTimeout(onEventDetail, 500);
  }
};
let createAutoAddCartButton = function (_0x425b48) {
  let _0x4e8b21 = document.createElement("button");
  _0x4e8b21.id = "hkticketkiller_auto_add_cart";
  _0x4e8b21.innerText = "Auto retry";
  let _0x296775 = function () {
    if (!citylineOptions.addCart) {
      citylineOptions.addCart = {};
    }
    let _0x5b9118 = (citylineOptions.addCart.autoClickSpeed || 1.5) * 1000;
    debugLog("autoClick");
    let _0x12a002 = document.getElementById("commonWarningMessageModal");
    if (_0x12a002 && _0x12a002.style.display !== "none") {}
    if (_0x4e8b21.dataset.stopAuto !== "yes") {
      debugLog("Click purchase button.");
      _0x425b48.click();
    }
    // TOLOOK
    setTimeout(() => {
      _0x296775();
    }, _0x5b9118);
  };
  _0x4e8b21.onclick = function () {
    if (_0x4e8b21.dataset.started !== "yes") {
      _0x4e8b21.dataset.started = "yes";
      _0x4e8b21.innerText = "Stop";
      _0x296775();
    } else {
      debugLog(_0x4e8b21.dataset.stopAuto);
      if (_0x4e8b21.dataset.stopAuto === "yes") {
        debugLog("Set to false");
        _0x4e8b21.dataset.stopAuto = "no";
      } else {
        debugLog("Set to true");
        _0x4e8b21.dataset.stopAuto = "yes";
      }
      if (_0x4e8b21.dataset.stopAuto === "yes") {
        _0x4e8b21.innerText = "Auto retry";
      } else {
        _0x4e8b21.innerText = "Stop";
      }
    }
  };
  _0x425b48.parentNode.appendChild(_0x4e8b21);
};
let createAutofillBtn = function () {
  if (document.getElementById("hkticketkiller_autofill_btn")) {
    return;
  }
  let _0x5212b5 = document.createElement("button");
  _0x5212b5.classList.add("btn-outline-primary");
  _0x5212b5.classList.add("btn");
  _0x5212b5.id = "hkticketkiller_autofill_btn";
  _0x5212b5.innerText = "Autofill by TicketBot";
  _0x5212b5.onclick = function () {
    if (citylineOptions && citylineOptions.paymentInfo && citylineOptions.paymentInfo.enable) {
      autofillPaymentInfo();
    } else {
      chrome.runtime.sendMessage({
        action: "goToSettings",
        page: "cityline"
      });
    }
  };
  let _0x1003ae = tools.createDivWithClass(["hkticketkiller"]);
  _0x1003ae.appendChild(_0x5212b5);
  let _0x15d412 = document.querySelector(".tips");
  if (!_0x15d412) {
    return;
  }
  let _0x352101 = document.createElement("style");
  _0x352101.innerHTML = ".hkticketkiller button:hover{ background-color: rgba(70, 90, 186, 0.1);}";
  _0x15d412.after(_0x352101);
  _0x15d412.after(_0x1003ae);
};
const concertDetailPageHelper = {
  createRefreshTimer: function () {
    let _0x4b963a = document.querySelector(".buyTicketBox");
    let _0x30bb86 = document.createElement("a");
    // _0x30bb86.target = "_blank";
    // _0x30bb86.href = "https://www.ticketbot-machine.com/article/%E5%A6%82%E4%BD%95%E5%85%81%E8%A8%B1%E5%BD%88%E5%87%BA%E5%BC%8F%E8%A6%96%E7%AA%97%EF%BC%9F";
    _0x30bb86.innerText = "Ticketbot自動刷新: 此頁將在整點自動刷新，如要啟用自動前往購票頁面功能, 請先允許彈出式視窗 (按此查看教學)";
    _0x4b963a.appendChild(_0x30bb86);
  },
  getNextHourTimestamp: function () {
    const _0x42b567 = new Date();
    const _0x55c877 = new Date(_0x42b567);
    _0x55c877.setHours(_0x42b567.getHours() + 1, 0, 0, 0);
    return _0x55c877.getTime();
  },
  run: function () {
    let _0x16b1d8 = document.getElementById("buyTicketBtn");
    if (_0x16b1d8) {
      _0x16b1d8.click();
    } else {
      this.createRefreshTimer();
    }
  }
};
const autoAddCartHelper = {
  hasSelectedQty: false,
  hasSelectedDate: false,
  autoLogin: function () {
    debugLog("autoLogin");
    let _0x25e562 = document.querySelector(".modal-dialog .btn-login");
    if (_0x25e562 && !_0x25e562.disabled) {
      _0x25e562.click();
    }
  },
  selectDate: function () {
    if (citylineOptions.addCart && citylineOptions.addCart.dateRule) {
      debugLog("autoAddCartHelper: selectDate");
      let _0x51324e = document.querySelectorAll(".date-box button");
      console.log(_0x51324e);
      let _0x381c25 = [];
      _0x51324e.forEach(_0x4d3cd1 => {
        _0x381c25.push(_0x4d3cd1);
      });
      let _0xb3fde8;
      let _0x30a92c = citylineOptions.addCart.dateRule;
      while (_0x381c25.length > 0) {
        if (_0x30a92c === "由上而下") {
          _0xb3fde8 = _0x381c25.shift();
        } else if (_0x30a92c === "由下而上") {
          _0xb3fde8 = _0x381c25.pop();
        } else if (_0x30a92c === "隨機") {
          _0xb3fde8 = _0x381c25.splice(Math.floor(Math.random() * _0x381c25.length), 1)[0];
        } else {
          break;
        }
        if (_0xb3fde8.disabled) {
          _0xb3fde8 = null;
        } else {
          break;
        }
      }
      if (_0xb3fde8) {
        debugLog("autoAddCartHelper: selected date");
        console.log(citylineOptions.addCart.rule);
        console.log(_0xb3fde8);
        _0xb3fde8.click();
        autoAddCartHelper.hasSelectedDate = true;
      }
    }
  },
  run: function () {
    autoAddCartHelper.autoLogin();
    if (!autoAddCartHelper.hasSelectedDate) {
      autoAddCartHelper.selectDate();
    }
    if (citylineOptions.addCart && citylineOptions.addCart.enable && citylineOptions.addCart.qty) {
      debugLog("autoAddCart");
      let _0x35fa0b = citylineOptions.addCart.qty || 0;
      let _0x3868af = document.querySelectorAll(".ticket-price-btn");
      let _0x52f655 = [];
      _0x3868af.forEach(_0xc1bf5 => {
        _0x52f655.push(_0xc1bf5);
      });
      let _0x3d2fce;
      while (_0x52f655.length > 0) {
        if (citylineOptions.addCart.rule === "由上而下") {
          _0x3d2fce = _0x52f655.shift();
        } else if (citylineOptions.addCart.rule === "由下而上") {
          _0x3d2fce = _0x52f655.pop();
        } else {
          _0x3d2fce = _0x52f655.splice(Math.floor(Math.random() * _0x52f655.length), 1)[0];
        }
        let _0xce5439 = _0x3d2fce.closest(".form-check");
        let _0x44482f = "";
        if (_0xce5439) {
          _0x44482f = _0xce5439.innerText;
        }
        let _0x2e0450 = citylineOptions.addCart.ignore;
        let _0x26da42 = [];
        if (_0x2e0450) {
          _0x2e0450 = _0x2e0450.replaceAll("，", ",");
          _0x26da42 = _0x2e0450.split(",");
        }
        _0x26da42.push("售罄");
        if (_0x26da42.some(_0x5575ef => _0x44482f.includes(_0x5575ef.trim()))) {
          _0x3d2fce = null;
        } else {
          break;
        }
      }
      if (_0x3d2fce) {
        _0x3d2fce.click();
      }
      let _0x1f5e74 = document.getElementById("ticketType0");
      if (_0x1f5e74 && _0x35fa0b) {
        _0x1f5e74.value = _0x35fa0b.toString();
        _0x1f5e74.dispatchEvent(new Event("change", {
          bubbles: true
        }));
        autoAddCartHelper.hasSelectedQty = true;
      }
      if (_0x3d2fce && _0x35fa0b && this.hasSelectedQty) {
        let _0x1169e9 = document.getElementById("hkticketkiller_auto_add_cart");
        if (_0x1169e9) {
          _0x1169e9.click();
        }
        return;
      }
    }
    // TOLOOK
    setTimeout(autoAddCartHelper.run, 500);
  }
};
let main = async function () {
  chrome.runtime.sendMessage({
    action: "getOptions"
  });
  debugLog("Start Loading bot");
  let _0x3f2f01 = window.location.href;
  debugLog("Current page: " + _0x3f2f01);
  let _0x346336 = document.getElementById("commonWarningMessageModal");
  let _0x2eeccd = document.getElementById("expressPurchaseBtn");
  const _0x56011b = new RegExp("*event.cityline.com/utsvInternet/*/login*".replace(/\*/g, "[^ ]*"));
  const _0x97a595 = new RegExp("*venue.cityline.com/utsvInternet/*/login*".replace(/\*/g, "[^ ]*"));
  const _0x27dfda = new RegExp("*event.cityline.com/utsvInternet/*/home*".replace(/\*/g, "[^ ]*"));
  if (_0x3f2f01.includes("busy") || _0x3f2f01.includes("msg")) {
    debugLog("queuing. Refresh in 3 sec");
    chrome.runtime.sendMessage({
      action: "saveWindowId"
    }, _0xef3073 => {});
    let _0x5b50c0 = new Date().getTime();
    let _0x5ec2f4 = Date.now();
    let _0x4cbd3c = function () {
      if (window.location.href.includes("venue.cityline.com")) {
        debugLog("Done. Set Window Size");
        const _0x39c65f = Math.floor(window.screen.height * 0.9);
        chrome.runtime.sendMessage({
          action: "setWindowSize",
          width: 0,
          height: _0x39c65f,
          from: "cityline"
        }, _0x28f2a6 => {});
        clearInterval(_0x48917f);
        return true;
      }
      return false;
    };
    let _0x48917f = // TOLOOK
    setInterval(() => {
      let _0x48b995 = document.getElementById("autoRetryMsg");
      let _0x5d2d86 = document.getElementById("autoRetryingMsg");
      let _0x3db92d = document.getElementById("btn-retry-en-1");
      let _0x26044f = document.getElementById("btn-retrying-en-1");
      let _0x41bd82 = new Date().getTime();
      let _0x2dfb09 = _0x41bd82 - _0x5b50c0;
      let _0x3b8ffa = (citylineOptions.speed || 3) * 1000;
      if (_0x3b8ffa === 10000) {
        debugLog("Speed=10. Disabled auto reload.");
        _0x4cbd3c();
        return;
      }
      if (_0x48b995) {
        _0x48b995.style.display = "none";
      }
      if (_0x5d2d86) {
        _0x5d2d86.style.display = "block";
        _0x5d2d86.innerHTML = "Hkticketkiller 重試中...<br>" + Math.ceil((_0x3b8ffa - _0x2dfb09) / 1000) + "秒後重試";
      }
      if (_0x3db92d) {
        _0x3db92d.style.display = "inline-block";
      }
      if (_0x26044f) {
        _0x26044f.style.display = "none";
      }
      if (_0x2dfb09 > _0x3b8ffa) {
        chrome.runtime.sendMessage({
          action: "saveWindowId"
        }, _0x17671f => {});
        if (_0x4cbd3c()) {
          return;
        }
        let _0x1c07c4 = "https://event.cityline.com";
        let _0x797a43 = new URL(window.location.href);
        let _0x1e1a20 = _0x797a43.searchParams.get("loc");
        if (_0x1e1a20) {
          _0x1c07c4 = _0x1c07c4 + "/queue?loc=" + encodeURIComponent(_0x1e1a20);
        }
        let _0x1f8f41 = function () {
          var _0x512809 = true;
          var _0x3e19a0 = _0x512809 ? 50 + Math.floor(Math.random() * 51) : Math.floor(Math.random() * 50);
          var _0x286e5e = {
            currentTimestamp: _0x5ec2f4
          };
          _0x286e5e.s = _0x3e19a0;
          var _0x1422ed = CryptoJS.enc.Base64.parse("c3ViY29uc2Npb3VzbmVzcw==");
          var _0x4d04dd = CryptoJS.enc.Utf8.parse(JSON.stringify(_0x286e5e));
          var _0x3a4842 = CryptoJS.AES.encrypt(_0x4d04dd, _0x1422ed, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
          });
          return _0x3a4842.toString();
        };
        let _0x461140 = function (_0x4b21d0) {
          var _0x88fbbb = {
            LDbfY: function (_0x5db77a, _0x35ce66) {
              return _0x5db77a !== _0x35ce66;
            }
          };
          _0x88fbbb.KfdYM = function (_0x88a11e, _0x1cb6d1) {
            return _0x88a11e % _0x1cb6d1;
          };
          _0x88fbbb.IMDuJ = function (_0x5647d3, _0x141676) {
            return _0x5647d3 === _0x141676;
          };
          _0x88fbbb.DAPOW = "gHpHB";
          _0x88fbbb.bXTux = "peMiu";
          while (_0x88fbbb.KfdYM(_0x4b21d0.length, 16) !== 0) {
            if (_0x88fbbb.IMDuJ(_0x88fbbb.DAPOW, _0x88fbbb.bXTux)) {
              return _0x547a57;
            } else {
              _0x4b21d0 += " ";
            }
          }
          return _0x4b21d0;
        };
        let _0x57405c = function (_0x3d71b9) {
          return Array.prototype.map.call(_0x3d71b9, _0x5d30d0 => ("0" + _0x5d30d0.toString(16)).slice(-2)).join("");
        };
        let _0x5bd72e = function (_0x2928c6) {
          return Uint8Array.from(_0x2928c6.match(/.{1,2}/g).map(_0xbf54c1 => parseInt(_0xbf54c1, 16)));
        };
        let _0x53d60f = function (_0x5088ea) {
          let _0x23055a = "";
          for (let _0x1cbc2e = 0; _0x1cbc2e < _0x5088ea.length; _0x1cbc2e++) {
            let _0x2d0834 = _0x5088ea.charCodeAt(_0x1cbc2e).toString(16);
            _0x23055a += _0x2d0834.padStart(2, "0");
          }
          return _0x23055a;
        };
        let _0x56d8b0 = function () {
          var _0x718db0 = true;
          var _0x67117c = _0x718db0 ? 50 + Math.floor(Math.random() * 51) : Math.floor(Math.random() * 50);
          var _0x4fb789 = {
            currentTimestamp: _0x5ec2f4,
            s: _0x67117c
          };
          var _0x5b663d = JSON.stringify(_0x4fb789);
          var _0xf94da0 = _0x461140(_0x5b663d);
          var _0x49871f = _0xf94da0.length;
          var _0x392e11 = Module._malloc(_0x49871f);
          var _0x533a61 = Module._malloc(_0x49871f);
          var _0x37471f = _0x5bd72e(_0x53d60f(_0xf94da0));
          Module.HEAP8.set(_0x37471f, _0x392e11);
          Module._get_data(_0x392e11, _0x49871f, _0x533a61);
          var _0x1c581a = new Uint8Array(Module.HEAP8.buffer, _0x533a61, _0x49871f);
          Module._free(_0x392e11);
          Module._free(_0x533a61);
          return _0x57405c(_0x1c581a);
        };
        let _0x48c04d = function () {
          var _0x1ffc82 = "";
          var _0x1133c2 = Module._malloc(48);
          Module.ccall("getData", "void", ["string", "string", "number", "number"], [{}, _0x5ec2f4.toString(), 48, _0x1133c2]);
          var _0x1f1943 = new Uint8Array(Module.HEAP8.buffer, _0x1133c2, 48);
          _0x1ffc82 = _0x57405c(_0x1f1943);
          Module._free(_0x1133c2);
          return _0x1ffc82;
        };
        let _0x6b070f = async function () {
          debugLog("Retry");
          if (_0x48b995) {
            _0x48b995.style.display = "none";
          }
          if (_0x5d2d86) {
            _0x5d2d86.style.display = "block";
          }
          if (_0x3db92d) {
            _0x3db92d.style.display = "none";
          }
          if (_0x26044f) {
            _0x26044f.style.display = "inline-block";
          }
          debugLog("Reset");
          _0x5b50c0 = new Date().getTime();
          return;
          let _0x75b9bd = _0x1c07c4;
          let _0xa61d2b = {};
          try {
            _0xa61d2b = await fetch(_0x75b9bd, {
              method: "POST",
              body: {
                data: _0x48c04d()
              },
              cache: "no-store",
              credentials: "include"
            });
          } catch (_0x24fd84) {
            console.log(_0x24fd84);
            debugLog("Fetch error. Reset");
            _0x5b50c0 = new Date().getTime();
          }
          if (_0xa61d2b.ok) {
            let _0x4daf4f = await _0xa61d2b.json();
            console.log(_0x4daf4f);
            if (_0x4daf4f.ACTION == "REDIRECT") {
              window.location.href = _0x4daf4f.REDIRECT_URL;
              clearInterval(_0x48917f);
            } else {
              debugLog("reset");
              _0x5b50c0 = new Date().getTime();
              _0x5ec2f4 = _0x4daf4f.STIMESTAMP;
            }
          }
        };
        _0x6b070f();
        return;
        window.location.href = _0x1c07c4;
        return;
        let _0x456e9e = document.getElementById("btn-retry-en-1");
        if (_0x456e9e && _0x456e9e.getAttribute("disabled") !== "disabled") {
          simulateClick(_0x456e9e, "mouseover");
          simulateClick(_0x456e9e, "click");
          _0x5b50c0 = new Date().getTime();
        } else {
          _0x4cbd3c();
        }
      }
    }, 500);
  } else if (_0x3f2f01.includes("shoppingBasket")) {
    debugLog("ShoppingBasket");
    createAutofillBtn();
    let _0x3ddd0a = document.getElementById("proceed");
    console.log("proceed");
    console.log(_0x3ddd0a);
    if (_0x3ddd0a) {
      _0x3ddd0a.addEventListener("click", function () {
        if (citylineOptions && citylineOptions.paymentInfo && citylineOptions.paymentInfo.enable) {
          autofillPaymentInfo();
        }
      });
    }
  } else if (_0x56011b.test(_0x3f2f01)) {
    debugLog("blocked? Refresh in 3 sec");
    // TOLOOK
    setTimeout(() => {
      window.location.href = window.location.href;
    }, 4000);
  } else if (_0x27dfda.test(_0x3f2f01)) {
    debugLog("earlyLink not redirected. Try reload in 3 sec");
    // TOLOOK
    setTimeout(() => {
      window.location.href = window.location.href;
    }, 3000);
  } else if (_0x3f2f01.includes("venue")) {
    let _0x1cd487 = document.getElementById("btn-retry-en-1");
    if (_0x1cd487) {
      debugLog("queuing. Refresh in 3 sec");
      // TOLOOK
      setInterval(() => {
        let _0x5283d5 = document.getElementById("btn-retry-en-1");
        if (_0x5283d5) {
          _0x5283d5.click();
        }
      }, 500);
      return;
    }
    debugLog("Done. Set Window Size");
    const _0x2a191f = Math.floor(window.screen.height * 0.9);
    chrome.runtime.sendMessage({
      action: "setWindowSize",
      width: 0,
      height: _0x2a191f,
      from: "cityline"
    }, _0x20a708 => {});
    let _0x443415 = document.querySelector(".activity-login-field-group input");
    if (_0x3f2f01.includes("eventDetail")) {
      onEventDetail();
    }
  } else if (_0x3f2f01.includes("/tc/")) {
    concertDetailPageHelper.run();
  } else if (_0x3f2f01.includes("shows.cityline.com")) {
    let _0x52de8c = function () {
      Element.prototype._addEventListener = Element.prototype.addEventListener;
      Element.prototype.addEventListener = function () {
        let _0x4f9932 = [...arguments];
        let _0x15c7dd = _0x4f9932[1];
        _0x4f9932[1] = function () {
          let _0x9082c8 = [...arguments];
          _0x9082c8[0] = Object.assign({}, _0x9082c8[0]);
          _0x9082c8[0].isTrusted = true;
          return _0x15c7dd(..._0x9082c8);
        };
        console.log("Trusted");
        console.log(this);
        return this._addEventListener(..._0x4f9932);
      };
    };
    let _0x32313e = function () {
      debugLog("autoClickBuy");
      let _0x13325c = document.getElementById("buyTicketBtn");
      if (_0x13325c) {
        _0x13325c.click();
      } else {
        // TOLOOK
        setTimeout(_0x32313e, 500);
      }
    };
    let _0x5b9ce4 = function () {
      let _0xc2f42a = document.createElement("button");
      _0xc2f42a.id = "countdownButton";
      _0xc2f42a.classList.add("load-button");
      _0xc2f42a.innerText = "按此自動前往購票 (hkticketkiller)";
      _0xc2f42a.onclick = function () {
        _0xc2f42a.disabled = true;
        _0xc2f42a.innerText = "開始發售後自動前往購票";
        _0xc2f42a.style.opacity = 0.3;
        _0xc2f42a.style.cursor = "default";
        // TOLOOK
        setTimeout(_0x32313e, 500);
      };
      let _0x66d77d = document.getElementsByClassName("buyTicketBox")[0];
      if (_0x66d77d) {
        _0x66d77d.appendChild(_0xc2f42a);
      }
    };
  }
  if (_0x2eeccd) {
    createAutoAddCartButton(_0x2eeccd);
    autoAddCartHelper.run();
  }
  return;
};
window.onload = async function () {
  chrome.runtime.sendMessage({
    action: "checkDeadline"
  });
};
window.addEventListener("message", function (_0x2e31cc) {
  debugLog("Window received message");
  let _0x320b42 = _0x2e31cc.data;
  if (_0x320b42.action === "recorderReady") {}
}, false);
chrome.runtime.onMessage.addListener(async function (_0x1d1f1a, _0x262b6c, _0x142619) {
  debugLog("Window received message from background");
  if (_0x1d1f1a.action === "getDeadlineCallback") {
    let _0x486816 = await checkDeadline(_0x1d1f1a);
    if (!_0x486816) {
      debugLog("Bot outdated. Please update to the latest version.");
    } else {
      main();
    }
    _0x142619(true);
  } else if (_0x1d1f1a.action === "checkDeadlineCallback") {
    if (_0x1d1f1a.disable) {
      debugLog("Bot outdated. Please update to the latest version.");
    } else {
      debugLog("Key valid.");
      main();
    }
    _0x142619(true);
  } else if (_0x1d1f1a.action === "getOptionsCallback") {
    _0x142619(true);
    if (_0x1d1f1a.options) {
      let _0x4bec19 = _0x1d1f1a.options;
      citylineOptions = _0x4bec19.cityline || {};
      if (_0x4bec19.hkticketing && _0x4bec19.hkticketing.speed) {
        citylineOptions.speed = _0x4bec19.hkticketing.speed;
      }
    }
    let _0x5b2ee9 = window.location.href;
    if (_0x5b2ee9.includes("shoppingBasket") && citylineOptions && citylineOptions.paymentInfo && citylineOptions.paymentInfo.enable) {
      // TOLOOK
      setTimeout(autofillPaymentInfo, 500);
    }
  }
  return true;
});